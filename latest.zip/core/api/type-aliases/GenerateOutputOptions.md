---
title: GenerateOutputOptions
editUrl: false
next: true
prev: true
---

> **GenerateOutputOptions** = `object`

Defined in: [generate/index.ts:18](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/index.ts#L18)

Options for controlling the generated output files.

## Properties

### actor?

> `optional` **actor**: \{ `disabled`: `true`; \} \| \{ `disabled?`: `false`; `interfaceFile?`: `boolean`; \}

Defined in: [generate/index.ts:22](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/index.ts#L22)

Options for controlling the generated actor files.

#### Type Declaration

\{ `disabled`: `true`; \}

#### disabled

> **disabled**: `true`

If `true`, skips generating the actor file (`<service-name>.ts`).

##### Default

```ts
false
```

\{ `disabled?`: `false`; `interfaceFile?`: `boolean`; \}

#### disabled?

> `optional` **disabled**: `false`

#### interfaceFile?

> `optional` **interfaceFile**: `boolean`

If `true`, generates a `<service-name>.d.ts` file that contains the same types of the `<service-name>.ts` file.
Useful to add to LLMs' contexts' to give knowledge about what types are available in the service.

Has no effect if `disabled` is `true`.

##### Default

```ts
false
```
