---
title: GenerateOptions
editUrl: false
next: true
prev: true
---

> **GenerateOptions** = `object`

Defined in: [generate/index.ts:48](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/index.ts#L48)

Options for the [generate](../functions/generate.md) function.

## Properties

### additionalFeatures?

> `optional` **additionalFeatures**: [`GenerateAdditionalFeaturesOptions`](GenerateAdditionalFeaturesOptions.md)

Defined in: [generate/index.ts:64](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/index.ts#L64)

Additional features to generate bindings with.

***

### didFile

> **didFile**: `string`

Defined in: [generate/index.ts:52](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/index.ts#L52)

The path to the `.did` file.

***

### outDir

> **outDir**: `string`

Defined in: [generate/index.ts:56](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/index.ts#L56)

The path to the directory where the bindings will be generated.

***

### output?

> `optional` **output**: [`GenerateOutputOptions`](GenerateOutputOptions.md)

Defined in: [generate/index.ts:60](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/index.ts#L60)

Options for controlling the generated output files.
