---
title: GenerateAdditionalFeaturesOptions
editUrl: false
next: true
prev: true
---

> **GenerateAdditionalFeaturesOptions** = `object`

Defined in: [generate/features/index.ts:3](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/features/index.ts#L3)

## Properties

### canisterEnv?

> `optional` **canisterEnv**: `object`

Defined in: [generate/features/index.ts:7](https://github.com/dfinity/icp-js-bindgen/blob/5d63e03c956275679ca572f084cd6c7883f67df2/src/core/generate/features/index.ts#L7)

If defined, generates a `canister-env.d.ts` file according to the provided options.

#### variableNames

> **variableNames**: `string`[]

The variable names to include in the `canister-env.d.ts` file.
